1. unzip wifi.zip -d ./

2.make

3.sudo make install

4.运行 wihotspot (或者在应用里找到图标打开就行)